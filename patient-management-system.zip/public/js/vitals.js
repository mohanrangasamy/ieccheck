$(document).ready(function(e){
	$("#record_date").datepicker({
		dateFormat: "dd/mm/yy"
	});
});