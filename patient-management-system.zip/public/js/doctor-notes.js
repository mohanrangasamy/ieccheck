$(document).ready(function(e){
	$("#visit_date").datepicker({
		dateFormat: "dd/mm/yy"
	});
});