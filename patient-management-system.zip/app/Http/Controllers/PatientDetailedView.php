<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PatientDetailedView extends Controller
{
    public function entry()
    {
    	
    }
}
