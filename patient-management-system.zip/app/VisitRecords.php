<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VisitRecords extends Model
{
    /**
	 * Change the default primary key
	 * @var string
	 */
	protected $primaryKey = 'visit_id';
}
